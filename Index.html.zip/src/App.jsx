import React, { useState, useEffect } from 'react';
import { Button } from './components/ui/button';
import { Input } from './components/ui/input';
import { Card, CardContent } from './components/ui/card';
import html2canvas from 'html2canvas';
import { FaWhatsapp } from 'react-icons/fa';

const backgrounds = [
  'bg-gradient-to-r from-green-300 via-blue-500 to-purple-600',
  'bg-gradient-to-r from-yellow-200 via-red-300 to-pink-400',
  'bg-gradient-to-r from-indigo-300 to-sky-500',
  "bg-[url('/medical-texture.png')] bg-cover bg-center text-white"
];

export default function HappyDoctorsDayApp() {
  const [name, setName] = useState('');
  const [speciality, setSpeciality] = useState('');
  const [photo, setPhoto] = useState(null);
  const [background, setBackground] = useState(backgrounds[0]);

  useEffect(() => {
    const audio = new Audio('/background-music.mp3');
    audio.loop = true;
    audio.play().catch((e) => console.log('Autoplay blocked'));
    return () => audio.pause();
  }, []);

  const handlePhotoUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => setPhoto(reader.result);
      reader.readAsDataURL(file);
    }
  };

  const downloadGreeting = () => {
    const card = document.getElementById('greeting-card');
    html2canvas(card).then((canvas) => {
      const link = document.createElement('a');
      link.download = `${name}-greeting.jpg`;
      link.href = canvas.toDataURL('image/jpeg');
      link.click();
    });
  };

  const shareOnWhatsApp = () => {
    const message = `Gratitude to Dr. ${name}, ${speciality} - from Team Dapalex! Thank you for your service.`;
    window.open(`https://wa.me/?text=${encodeURIComponent(message)}`, '_blank');
  };

  return (
    <div className="p-4 max-w-2xl mx-auto animate-fade-in">
      <h1 className="text-3xl font-extrabold text-center mb-2 text-blue-800 drop-shadow-md animate-bounce">🎉 Happy Doctor's Day 🎉</h1>
      <h2 className="text-2xl font-bold mb-4 text-center">Welcome to the <span className='text-blue-700 font-extrabold'>Happy DoctorsDay</span> Web App</h2>

      <div className="grid gap-4">
        <Input placeholder="Doctor's Name" value={name} onChange={(e) => setName(e.target.value)} />
        <Input placeholder="Speciality" value={speciality} onChange={(e) => setSpeciality(e.target.value)} />
        <Input type="file" accept="image/*" onChange={handlePhotoUpload} />
        <div className="flex gap-4 overflow-x-auto items-center">
          {backgrounds.map((bg, idx) => (
            <div key={idx} className="flex flex-col items-center text-center">
              <button
                onClick={() => setBackground(bg)}
                className={`w-14 h-14 rounded-full border-2 shadow-inner ${bg}`}
              ></button>
              <span className="text-xs mt-1 text-gray-700">
                {bg.includes('url') ? 'Medical' : `Theme ${idx + 1}`}
              </span>
            </div>
          ))}
        </div>
      </div>

      <Card id="greeting-card" className={`mt-6 ${background} text-white p-6 rounded-2xl shadow-xl relative overflow-hidden`}>
        <div className="absolute inset-0 opacity-20 bg-[url('/medical-texture.png')] bg-cover bg-center mix-blend-soft-light pointer-events-none"></div>
        <CardContent className="text-center relative z-10">
          <h2 className="text-2xl font-extrabold animate-bounce text-white mb-4">🎉 Happy Doctor's Day 🎉</h2>
          {photo && <img src={photo} alt="Doctor" className="mx-auto mb-4 rounded-full w-32 h-32 object-cover border-4 border-white animate-zoom-in" />}
          <h2 className="text-xl font-bold">Dr. {name}</h2>
          <p className="italic">{speciality}</p>

          <p className="mt-6 text-lg animate-fade-in">We deeply appreciate your unwavering service and compassion.<br/>Wishing you a Happy Doctor's Day!</p>

          <h1 className="text-4xl font-extrabold mt-4 animate-pulse">Thank You!</h1>

          <p className="mt-4 font-bold text-yellow-300">
            — Team Dapalex — <br />
            <span className="text-white">Dapalex SM | Dapalex M | Dapalex P | Dapalex S</span>
          </p>
        </CardContent>
      </Card>

      <div className="mt-6 flex gap-4 justify-center">
        <Button onClick={downloadGreeting}>Download</Button>
        <Button onClick={shareOnWhatsApp} className="bg-green-500 hover:bg-green-600 text-white">
          <FaWhatsapp className="mr-2" /> Share on WhatsApp
        </Button>
      </div>
    </div>
  );
}
